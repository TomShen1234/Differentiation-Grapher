import Cocoa
import SwiftUI
import PlaygroundSupport

var contentView = DifferentiationView()
let hostingView = NSHostingView(rootView: contentView)

// Create the window and set the content view.
hostingView.setFrameSize(NSSize(width: 700, height: 500))

PlaygroundPage.current.liveView = hostingView
