//
//  DifferentiationView.swift
//  Series and Differentiation
//
//  Created by Tom Shen on 2020/5/6.
//  Copyright © 2020 Tom Shen. All rights reserved.
//

import SwiftUI

public struct DifferentiationView: View {
    @ObservedObject var calculator = DerivativeCalculator()
    
    @State var xSpacingStr: String = "1"
    @State var ySpacingStr: String = "1"
    
    @State var graphTangentAndNormal = true
    
    @GestureState var lineVisible = false
    @ObservedObject var dragHandler = GesturePositionHandler()
    
    var verticalTicksCount: Int = 8
    var horizontalTicksCount: Int = 18

    var xSpacing: Double {
        return Double(xSpacingStr) ?? 1
    }
    
    var ySpacing: Double {
        return Double(ySpacingStr) ?? 1
    }
    
    public init() {}
    
    public var body: some View {
        VStack {
            Image("derivative")
                .resizable()
                .frame(width: 150, height: 40)
            
            HStack {
                EquationIcon(letterNumerator: "")
                Text("=")
                TextField("Enter Equation", text: $calculator.input)
                Text("at x =")
                TextField("", text: $calculator.inputValue)
                    .frame(maxWidth: 50)
            }
            
            HStack {
                EquationIcon()
                Text("=")
                Text(calculator.result)
            }
            
            HStack {
                Text("Tangent:")
                Text("y =")
                Text(calculator.tangentResult)
                    .foregroundColor(.blue)
            }
            
            HStack {
                Text("Normal:")
                Text("y =")
                Text(calculator.normalResult)
                    .foregroundColor(.red)
            }
            
            HStack {
                Text("X Scale:")
                TextField("", text: $xSpacingStr)
                    .frame(width: 60)
                Text("Y Scale:")
                TextField("", text: $ySpacingStr)
                    .frame(width: 60)
                Toggle(isOn: $graphTangentAndNormal) {
                    Text("Graph Tangent and Normal")
                }
            }
            
            GeometryReader { geometry in
                // Attach gesture on rectangle background
                Rectangle()
                    .foregroundColor(Color(.controlBackgroundColor))
                    .gesture(DragGesture(minimumDistance: 0, coordinateSpace: .local)
                        .updating(self.$lineVisible, body: { value, state, _ in
                            state = true
                            if value.location.x < 0 || value.location.x > geometry.size.width {
                                // Drag is outside bound, ignore data
                                return
                            }
                            self.dragHandler.dragXPosition = value.location.x
                            // Calculate x value at selection point
                            let width = geometry.size.width
                            let targetX = value.location.x
                            let dividedWidth = width / CGFloat(self.horizontalTicksCount)
                            let dragXValue = -(((width / 2) - targetX) / dividedWidth)
                            self.calculator.dragXValue = Double(dragXValue) * self.xSpacing
                        }).onEnded({ _ in
                            // local state is reset automatically
                            // reset calculator state
                            self.calculator.dragValid = false
                        }))
                
                // Graph elements
                GraphPath(geometry: geometry,
                          verticalTicksCount: self.verticalTicksCount,
                          horizontalTicksCount: self.horizontalTicksCount)
                
                // Plot lines
                if self.calculator.isValid {
                    LinePath(geometry: geometry,
                             strokeColor: Color(.labelColor),
                             xSpacing: self.xSpacing,
                             ySpacing: self.ySpacing,
                             verticalTicksCount: self.verticalTicksCount,
                             horizontalTicksCount: self.horizontalTicksCount,
                             equation: self.calculator.input)
                    
                    if self.graphTangentAndNormal {
                        LinePath(geometry: geometry,
                                 strokeColor: .blue,
                                 xSpacing: self.xSpacing,
                                 ySpacing: self.ySpacing,
                                 verticalTicksCount: self.verticalTicksCount,
                                 horizontalTicksCount: self.horizontalTicksCount,
                                 equation: self.calculator.tangentResult)
                        
                        LinePath(geometry: geometry,
                                 strokeColor: .red,
                                 xSpacing: self.xSpacing,
                                 ySpacing: self.ySpacing,
                                 verticalTicksCount: self.verticalTicksCount,
                                 horizontalTicksCount: self.horizontalTicksCount,
                                 equation: self.calculator.normalResult)
                    }
                }
                
                if self.lineVisible {
                    //Rectangle()
                    SelectionPath(geometry: geometry, xPosition: self.dragHandler.dragXPosition, strokeColor: Color(.labelColor))
                }
            }
            
            HStack {
                if !calculator.dragValid {
                    Text("Drag on graph to inspect.")
                } else {
                    Text("x = \(calculator.dragXValue)")
                    Text("y = \(calculator.dragResult)")
                    if graphTangentAndNormal {
                        Text("y = \(calculator.dragResultTangent)")
                            .foregroundColor(.blue)
                        Text("y = \(calculator.dragResultNormal)")
                            .foregroundColor(.red)
                    }
                }
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding([.leading, .top, .trailing]) // Slightly reduce bottom padding
        .padding(.bottom, 9)
    }
}

final class GesturePositionHandler: ObservableObject {
    @Published var dragXPosition: CGFloat = 0
}

/// The dy/dx icon with customizable letters for reusability
struct EquationIcon: View {
    var letterDenominator = "x"
    var letterNumerator = "y"
    
    var body: some View {
        VStack(spacing: 1) {
            Text("d\(letterNumerator)")
            Divider().frame(width: 20).background(Color(.labelColor))
            Text("d\(letterDenominator)")
        }
    }
}

/// This view is responsible for drawing the line of the equation
struct LinePath: View {
    var geometry: GeometryProxy
    
    var strokeColor: Color
    
    var xSpacing: Double = 1
    var ySpacing: Double = 1
    
    var verticalTicksCount: Int = 8
    var horizontalTicksCount: Int = 18
    
    var xMax: Double {
        return Double(horizontalTicksCount) / 2 * xSpacing
    }
    var yMax: Double {
        return Double(verticalTicksCount) / 2 * ySpacing
    }
    
    var equation: String
    var constants: [String : Double] = [:]
    var symbols: [Expression.Symbol : Expression.SymbolEvaluator] = [:]
    
    var body: some View {
        Path { path in
            let width = geometry.size.width
            let height = geometry.size.height
            
            let dividedWidth = width / CGFloat(horizontalTicksCount)
            let dividedHeight = height / CGFloat(verticalTicksCount)
            
            var continueCalled = true
            
            // Every iteration will increase x by 0.05
            let incrementCount = 0.01
            var x = -xMax
            while x < xMax {
                // Always increment x before leaving scope
                defer { x += incrementCount }
                
                // Solve the expression for y value first
                var symbolsCopy = symbols
                symbolsCopy[.variable("x")] = { _ in x }
                let expression = Expression(equation, constants: constants, symbols: symbolsCopy)
                guard let y = try? expression.evaluate() else {
                    // Just ignore for now
                    //print("error calculating for graph")
                    continueCalled = true
                    continue
                }
                
                // Plot line
                if abs(y) > yMax {
                    // Exceeded max value
                    continueCalled = true
                    continue
                }
                
                let dividedX = x / xSpacing
                let dividedY = y / ySpacing
                
                // Coordinate starts at top left
                let targetX = (width / 2) + (dividedWidth * CGFloat(dividedX))
                let targetY = (height / 2) - (dividedHeight * CGFloat(dividedY))
                let targetPoint = CGPoint(x: targetX, y: targetY)
                if continueCalled {
                    path.move(to: targetPoint)
                    continueCalled = false
                } else {
                    path.addLine(to: targetPoint)
                }
            }
        }.stroke(strokeColor)
    }
}

/// This view is responsible for drawing the background components of the graph
struct GraphPath: View {
    var geometry: GeometryProxy
    
    var verticalTicksCount: Int = 8
    var horizontalTicksCount: Int = 18
    
    var body: some View {
        // Draw graph background components
        Path { path in
            let width = geometry.size.width
            let height = geometry.size.height
            
            // Draw vertical line
            path.move(to: CGPoint(x: width / 2, y: 0))
            path.addLine(to: CGPoint(x: width / 2, y: height))
            
            // Draw horizontal line
            path.move(to: CGPoint(x: 0, y: height / 2))
            path.addLine(to: CGPoint(x: width, y: height / 2))
            
            // Draw vertical ticks
            let dividedHeight = height / CGFloat(verticalTicksCount)
            for count in 1..<verticalTicksCount {
                // Skip middle one
                if count == verticalTicksCount / 2 { continue }
                let currentHeight = height - (dividedHeight * CGFloat(count))
                let startWidth = width / 2 - 5
                let endWidth = width / 2 + 5
                path.move(to: CGPoint(x: startWidth, y: currentHeight))
                path.addLine(to: CGPoint(x: endWidth, y: currentHeight))
            }
            
            // Draw horizontal ticks
            let dividedWidth = width / CGFloat(horizontalTicksCount)
            for count in 1..<horizontalTicksCount {
                // Skip middle one
                if count == horizontalTicksCount / 2 { continue }
                let currentWidth = width - (dividedWidth * CGFloat(count))
                let startHeight = height / 2 - 5
                let endHeight = height / 2 + 5
                path.move(to: CGPoint(x: currentWidth, y: startHeight))
                path.addLine(to: CGPoint(x: currentWidth, y: endHeight))
            }
        }.stroke()
    }
}

/// Draw a vertical line at xPosition to show selection
struct SelectionPath: View {
    var geometry: GeometryProxy
    var xPosition: CGFloat
    var strokeColor: Color
    
    var body: some View {
        Path { path in
            let yPositionSource: CGFloat = 0
            path.move(to: CGPoint(x: xPosition, y: yPositionSource))
            
            let yPositionTarget = geometry.size.height
            path.addLine(to: CGPoint(x: xPosition, y: yPositionTarget))
        }.stroke(strokeColor)
    }
}

final class DerivativeCalculator: ObservableObject {
    var input: String = "" {
        didSet {
            calculate()
        }
    }
    
    var inputValue: String = "1" {
        didSet {
            calculate()
        }
    }
    
    @Published var result = ""
    @Published var tangentResult = ""
    @Published var normalResult = ""
    
    @Published var isValid = false
    
    @Published var dragValid = false
    @Published var dragXValue: Double = 0 {
        didSet {
            calculateDrag()
        }
    }
    @Published var dragResult = ""
    @Published var dragResultTangent = ""
    @Published var dragResultNormal = ""
    
    init() {
        // There is no result at launch
        setNoResult()
    }
    
    func calculate() {
        guard input.count > 0 else {
            setNoResult()
            return
        }
        
        guard let doubleInputValue = Double(inputValue) else {
            setInvalidResult()
            return
        }
        
        // Replace x with x + h
        let derivativePartOne = input.replacingOccurrences(of: "x", with: "(x + h)")
        let derivativePartTwo = input
        
        let derivativeFunction = "((\(derivativePartOne)) - (\(derivativePartTwo))) / h"
        
        // Solve the expression
        let expression = Expression(derivativeFunction, constants: [
            "h": 0.000000001
        ], symbols: [
            .variable("x"): { _ in doubleInputValue},
        ])
        
        let evaluateResultRounded: Double
        do {
            let evaluateResult = try expression.evaluate()
            evaluateResultRounded = round((evaluateResult * 10000)) / 10000
            result = "\(evaluateResultRounded)"
        } catch {
            setInvalidResult()
            return
        }
        
        // Calculate tangent with y=mx+b
        // we need b so b = y - mx
        // First calculate point of contact by evaluating input
        // Solve the expression
        let contactExp = Expression(input, constants: [:], symbols: [
            .variable("x"): { _ in doubleInputValue},
        ])
        let contactY: Double
        do {
            contactY = try contactExp.evaluate()
        } catch {
            setInvalidResult()
            return
        }
        let tangentIntercept = contactY - (evaluateResultRounded * doubleInputValue)
        tangentResult = "\(evaluateResultRounded) * x + \(tangentIntercept)"
        
        // Calculate normal using the reciprocol method
        let slopeNegativeReciprocol = -1.0 / evaluateResultRounded
        let normalSlopeRounded = round(slopeNegativeReciprocol * 10000) / 10000
        let normalIntercept = contactY - (normalSlopeRounded * doubleInputValue)
        normalResult = "\(normalSlopeRounded) * x + \(normalIntercept)"
        
        isValid = true
    }
    
    func setNoResult() {
        result = "Enter equation"
        tangentResult = "Enter equation"
        normalResult = "Enter equation"
        isValid = false
    }
    
    func setInvalidResult() {
        result = "Invalid"
        tangentResult = "Invalid"
        normalResult = "Invalid"
        isValid = false
    }
    
    func calculateDrag() {
        if !isValid {
            dragValid = false
            return
        }
        
        let exp = Expression(self.input, constants: [:], symbols: [.variable("x"):{_ in self.dragXValue}])
        if let eval = try? exp.evaluate() {
            dragResult = "\(eval.round2Digits)"
        } else {
            dragResult = "Invalid"
        }
        
        let tangentExp = Expression(self.tangentResult, constants: [:], symbols: [.variable("x"):{_ in self.dragXValue}])
        if let tangentEval = try? tangentExp.evaluate() {
            dragResultTangent = "\(tangentEval.round2Digits)"
        } else {
            dragResultTangent = "Invalid"
        }
        
        let normalExp = Expression(self.normalResult, constants: [:], symbols: [.variable("x"):{_ in self.dragXValue}])
        if let normalEval = try? normalExp.evaluate() {
            dragResultNormal = "\(normalEval.round2Digits)"
        } else {
            dragResultNormal = "Invalid"
        }
        
        dragValid = true
    }
}

extension Double {
    var round2Digits: Double {
        let multiply100 = self * 100
        return multiply100.rounded() / 100
    }
}
